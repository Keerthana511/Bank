export const formatCurrency = (n) => '₹' + Number(n).toLocaleString()
