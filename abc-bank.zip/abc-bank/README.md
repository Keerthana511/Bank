# ABC Bank (mock)

This is a scaffolded React app (Vite + Tailwind + Redux Toolkit) built according to the provided SRS.
It uses mock services and sample data.

## Setup

1. Install dependencies:
   npm install

2. Run dev server:
   npm run dev

This is mock/demo only — replace service endpoints in src/services/*.js when connecting to your backend.
